import React from 'react';
import HeaderProducto from './components/HeaderProducto';
import DescripcionProducto from './components/DescripcionProducto';
import InfoProducto from './components/InfoProducto';

function DetalleProducto() {
  return (
    <div className="product-detail">
      <HeaderProducto />
      <DescripcionProducto />
      <InfoProducto />
    </div>
  );
}

export default DetalleProducto;
