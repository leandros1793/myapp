import React from 'react';

function DescripcionProducto() {
  return (
    <div className="description">
      <p>Descripción del Producto</p>
    </div>
  );
}

export default DescripcionProducto;
