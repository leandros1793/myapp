import React from 'react'

const HeaderProducto = () => {
  return (
    <header>
      <h1>Nombre del Producto</h1>
    </header>
  )
}

export default HeaderProducto
